
Kokoro Infrastructure
----------------------

The files in this directory serve as plumbing for running Protobuf
tests under Kokoro, our internal CI.